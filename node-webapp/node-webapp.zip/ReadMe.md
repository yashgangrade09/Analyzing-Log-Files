To run the program on the localhost server, use server_localhost.js
To run the node.js server locally, use "node server_localhost" command in the terminal.

server.js file is modified so as to make it compatible with AWS.

index.html contains the first page where the user is asked to upload and submit a file. 
Logstats.html is the second page which shows the statistics in a tabular format, a pie chart depicting the same statistics, and a link to the source code (redirects to github repository).